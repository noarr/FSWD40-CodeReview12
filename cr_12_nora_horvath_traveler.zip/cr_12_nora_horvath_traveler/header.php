<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset') ?>">

	<meta name="description" content="<?php bloginfo('description'); ?>">
	
	<title><?php bloginfo('name'); ?></title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">

	<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>

	<style>
		a {
			color:green;
		}
		a:hover {
			text-decoration: none;
		}
		.bg-hero {
			background-image: url("https://sb.ecobnb.net/app/uploads/sites/3/2017/11/sustainable-travelling-tips.jpg");
			background-position: center center;
			background-repeat: no-repeat;
			background-size:cover;
			
		}

		.jumbotron{
			color: black;
		}

	</style>

<?php wp_head(); ?>
</head>


<body>
	<header>
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<ul class="navbar-nav d-flex justify-content-around ">
								<li class="nav-item active">
									<a class="nav-link" href="#">About<span class="sr-only"></span></a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="#">Co2 emission</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="#">Sustainable Travel Tips</a>
								</li>
								<li class="nav-item">
									<a class="nav-link " href="#">Responsible Lifestyle</a>
								</li>
								<li class="nav-item">
									<a class="nav-link " href="#">Youtube</a>
								</li>
								
								<li>
									<div class="" style="font-size: 26px; color: white;">
										<div class="socialMedia d-flex justify-content-between">
											<a href="#" class="m-1">
												<i class="fab fa-facebook-square"></i>
											</a>
											<a href="#" class="m-1">
												<i class="fab fa-instagram"></i>
												
											</a>
											<a href="#" class="m-1">
												<i class="fab fa-twitter-square"></i>
											</a>
											<a href="#" class="m-1">
												
												<i class="fab fa-twitter-square"></i>
											</a>
											<a href="#" class="m-1">
												
												<i class="fab fa-youtube-square"></i>
											</a>
											<a href="#" class="m-1">
												<i class="fab fa-tumblr"></i>
											
											</a>	
							</div>
						</div>
								</li>
							</ul>
						</div>
						
						
					</div>		

				</div>
			</div>
		</nav>
		
		<div class="jumbotron jumbotron-fluid d-flex flex-column justify-content-around align-items-center bg-hero">
			<h1 class="display-3 mt-5 text-center"><?php bloginfo('name'); ?></h1>
			<h3 class="lead"><?php bloginfo('description') ?></h3>
		</div>
	</header>

	<main>
		<div class="container">