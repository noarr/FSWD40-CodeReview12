<?php get_header() ?>
			<div class="row">
				<div class="col-8">
					<div class="container">
						<div class="row">
							
								<?php if ( have_posts() ) : ?>
								<?php 
									while (have_posts()) : the_post();
								 ?>
								
									<div class="col d-flex flex-column align-items-center">

								
										<h2 class="headline text-center">
											<a href="<?php the_permalink(); ?>">
												<div class=" img-thumbnail ">
													<img src="1.jpg" alt="" class="img-fluid">
												</div>
												<?php the_title(); ?>	
											</a>
										</h2>

										<p class="blog-post-meta">
											<?php the_time('d.m.Y G:i'); ?>
					            			by <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
					            				<?php the_author(); ?>
					            			</a>
					            		</p>

										<p class="articlePreview">
											<?php the_content(); ?>
										</p>
									</div>

								 <?php endwhile; ?>
						        <?php else:  ?>
						        <p><?php __('No Posts Found'); ?></p>
						        <?php endif; ?>
						</div>
					
						<div class="row" style="font-size: 15px;">
			        		<div class="col">
			        			
			        		<?php comments_template(); ?>
			        		</div>
						</div>
					</div>
				</div>
				
				<div class="col-4">
					<?php if(is_active_sidebar('sidebar')):
					dynamic_sidebar('sidebar');
					endif ?>
				</div>
			</div>
						
		</div>


		</div>
	</main>
<?php get_footer(); ?>